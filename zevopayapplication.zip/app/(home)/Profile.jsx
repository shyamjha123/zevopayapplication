import { View, Text } from 'react-native'
import React from 'react'

const Profile = () => {
  return (
    <View>
      <Text style={{color:"red"}}>Profile</Text>
    </View>
  )
}

export default Profile